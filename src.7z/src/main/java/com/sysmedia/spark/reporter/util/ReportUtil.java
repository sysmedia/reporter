package com.sysmedia.spark.reporter.util;

public class ReportUtil {
    public void generateReport(String shopId) {

    }
}
