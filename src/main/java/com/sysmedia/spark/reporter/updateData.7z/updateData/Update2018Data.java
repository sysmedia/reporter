package com.sysmedia.spark.reporter.updateData;

import com.sysmedia.spark.reporter.util.DataBaseConnection;
import com.sysmedia.spark.reporter.util.DataCollection;

/**
 * update 2018 data as some data were missed by duodian
 * parameter:  shop, ratio
 * if shop = 999999, update all 2018 data
 */

public class Update2018Data {
    public static void  main(String[] args) {
        System.out.println("args length is " + args.length);
        DataBaseConnection conn = new DataBaseConnection();
        DataCollection collection = new DataCollection();
        String shopId =  args[0];
        float ratio = Float.valueOf(args[1]);
        String sql;

       /* //销售额  t_shop_count	totalPrice
        sql = "update t_shop_count set totalPrice = CONCAT((CONVERT(totalPrice,DECIMAL(16,0)) * " + ratio + "), '') where year = 2018 and shop = " + shopId;
        conn.update(sql);

        //销售量       t_shop_count	salecount
        sql = "update t_shop_count set salecount = CONCAT((CONVERT(salecount,DECIMAL(16,0)) * " + ratio + "), '') where year = 2018 and shop = " + shopId;
        conn.update(sql);

        // 查询 , 购物人次 信息， t_shop_count	totalcount
        sql = "update t_shop_count set totalcount = CONCAT((CONVERT(totalcount,DECIMAL(16,0)) * " + ratio + "), '') where year = 2018 and shop = " + shopId;
        conn.update(sql);

        //查询会员购物人次 ，t_shop_customer_count	totalcount
        sql = "update t_shop_customer_count set totalcount = CONCAT((CONVERT(totalcount,DECIMAL(16,0)) * " + ratio + "), '') where year = 2018 and shop = " + shopId;
        conn.update(sql);*/

        //净值等级  t_customertype 	value
        sql = "update t_customertype set value = CONCAT(CONVERT((CONVERT(value,SIGNED integer) * " + ratio + "), DECIMAL(16,0)), '') where year = 2018 and shop = " + shopId;
        conn.update(sql);


    }
}
